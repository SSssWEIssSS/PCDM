from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import umap

def calculate_pca_of_gradients(logger, gradients, num_components):
    pca = PCA(n_components=num_components)

    logger.info("Computing {}-component PCA of gradients".format(num_components))

    return pca.fit_transform(gradients)

def calculate_umap_of_gradients(logger, gradients, num_components):
    reducer=umap.UMAP(n_neighbors=100, min_dist=0.25,n_components=num_components)
    #n_neighbors=低值更关注局部（可能损害全局），高值专注全局，丢失精度, min_dist=打包的密集程度,越小约密集，metric距离计算环境

    logger.info("Computing {}-component UMAP of gradients".format(num_components))

    return reducer.fit_transform(gradients)

def calculate_tsne_of_gradients(logger, gradients, num_components):
    tsne = TSNE(perplexity=30,n_components=num_components,init='pca')
    #perplexity=30越大越全局，init='pca'可以以pca为基础，默认随机

    logger.info("Computing {}-component TSNE of gradients".format(num_components))

    return tsne.fit_transform(gradients)